Please keep the 'lookAtTheseNerdsLmao' folder in the same folder as the JAR file, otherwise this game will not work.

The git repo for this game is here: https://github.com/IDontHaveAnyClueWhatToPutHere/UpronSimulator2012

# le readme has arrived

aight ok so basically this was for a game jam in march 2020

theme was 'it has to have a story' but also 'growth'

and uhh yeah this game is about defending the Ron Paul presidential campaign headquarters (aka reddit in 2012)
from all the downronners and such whilst letting the upronners upron
all of your epic posts and such, using your trusty BraveryStick.

yes you need a mouse to play this game,
no it does not support fullscreen,
and yes it is absolute shite.

# CREDITS

## code stuff

* code and such: me
* sample code: provided by Dr Dimitri Ognibene
* Information about getting resources from a static context: JB Nizet on Stack Overflow (https://stackoverflow.com/a/8362018)
* utilities/FontsWhatIHave.java: pretty much unceremoniously nicked from http://www.java2s.com/Tutorial/Java/0261__2D-Graphics/Togetallavailablefontsinyoursystem.htm

## not code stuff

* Ron "Ron Paul" Paul: himself
* snoo.png, upvote.png, downvote.png: reddit
* BraveryStick.png, BraveryStickFlipped.png: me (made with ms paint)

## stuff

* im stuff
