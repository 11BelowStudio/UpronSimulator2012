Please keep the 'lookAtTheseNerdsLmao' folder in the same folder as the JAR file, otherwise this game will not work.

The git repo for this game is here: https://github.com/11BelowStudio/UpronSimulator2012
the itch.io page is here: itch.io page: https://11belowstudio.itch.io/upron-simulator-2012

# le readme has arrived

ok so basically this game was made for a game jam hosted by the University of Essex Game Development Society, between 7/3/20-8/3/20.

The theme was 'it has to have a story' but also 'growth'

and uhh yeah this game is about defending the Ron Paul presidential campaign headquarters (aka reddit in 2012)
from all the downronners and such whilst letting the upronners upron
all of your epic posts and such, using your trusty BraveryStick.

yes you need a mouse to play this game,
no it does not support fullscreen,
and yes, I know, this game sucks.

# CONTROLS

* Move your mouse to swing your BraveryStick (So Brave!)
    * Stop the downrons (blue arrows) from getting to you
    * Let the uprons (orange arrows) get to you
    * Survive for as long as possible

# CREDITS

## code stuff

* code and such: me
* sample code: provided by Dr Dimitri Ognibene
* Information about getting resources from a static context: JB Nizet on Stack Overflow (https://stackoverflow.com/a/8362018)

## not code stuff

* Ron "Ron Paul" Paul: himself
* snoo.png, upvote.png, downvote.png: reddit
* BraveryStick.png, BraveryStickFlipped.png: me (made with ms paint)
* heavily inspired by https://old.reddit.com/r/braveryjerk

## stuff

* im stuff
